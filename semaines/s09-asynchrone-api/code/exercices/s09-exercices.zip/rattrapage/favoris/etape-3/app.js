// Pas à pas — Mes musées favoris (vendredi matin).
// Tapez le code et ses commentaires, une étape à la fois, avec le groupe.
// Déjà écrit : les données, les éléments de la page, la liste des musées et le résumé.
import { MUSEUMS } from '../data/musees-bretagne.js';

// The key under which this page stores its favourites. One key per page:
// every page opened with Live Preview shares the same localStorage.
const KEY = 'pas-a-pas-favoris';
console.log('Clé de cette page :', KEY);

const summary = document.querySelector('#resume');
const list = document.querySelector('#liste');
const clearButton = document.querySelector('#vider');

// Au chargement : les favoris déjà enregistrés
let favorites = loadFavorites();

// Already written: the number of favourites and their identifiers.
function showSummary() {
  summary.textContent = `${favorites.length} favori(s) : ${favorites.join(', ')}`;
}

// Already written: one button per museum of the Côtes-d'Armor. A click calls choose(id).
for (const museum of MUSEUMS.filter((item) => item.Departement === "Côtes-d'Armor")) {
  const item = document.createElement('li');
  const button = document.createElement('button');
  button.type = 'button';
  button.textContent = `Ajouter : ${museum.Nom_officiel}`;
  button.addEventListener('click', () => choose(museum.Identifiant));
  item.append(button);
  list.append(item);
}

showSummary();

// Already written: the button "Tout retirer" empties the favourites of the page.
clearButton.addEventListener('click', () => {
  // removeItem : efface ce qui est rangé sous la clé KEY
  localStorage.removeItem(KEY);
  favorites = [];
  showSummary();
});

// Étape 1 — Un clic sur un musée appelle cette fonction.
function choose(id) {
  // Déjà dans les favoris : on ne l'ajoute pas deux fois
  if (favorites.includes(id)) {
    // return : la fonction s'arrête, rien n'est ajouté
    return;
  }
  // Spread : un nouveau tableau, avec cet identifiant en plus
  favorites = [...favorites, id];
  // JSON.stringify : le tableau devient un texte
  const text = JSON.stringify(favorites);
  // setItem : range ce texte dans le navigateur, sous KEY
  localStorage.setItem(KEY, text);
  // Met à jour le résumé de la page
  showSummary();
}

// Étape 2 — Relit les favoris rangés dans le navigateur
// Relit les favoris rangés dans le navigateur
function loadFavorites() {
  // getItem : le texte rangé sous KEY, ou null si rien
  const text = localStorage.getItem(KEY);
  // Rien d'enregistré : on part d'un tableau vide
  if (text === null) {
    // Un tableau vide : aucun favori
    return [];
  }
  // JSON.parse : le texte redevient un tableau
  return JSON.parse(text);
}
